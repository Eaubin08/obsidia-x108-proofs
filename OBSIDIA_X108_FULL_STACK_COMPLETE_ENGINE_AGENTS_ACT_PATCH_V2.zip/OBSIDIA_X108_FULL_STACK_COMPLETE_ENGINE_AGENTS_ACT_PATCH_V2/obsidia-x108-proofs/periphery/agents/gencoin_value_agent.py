from __future__ import annotations

from typing import Any

from periphery.agent_contracts import AgentLayer, NonSovereignAgentSpec
from periphery.gencoin import compute_gencoin

SPEC = NonSovereignAgentSpec(
    agent_id="GENCOIN_VALUE_AGENT",
    layer=AgentLayer.GENCOIN,
    description="Calcule Gencoin post-proof, sans autoriser ni exécuter.",
)

def compute(action: Any, packet: Any, ticket: Any):
    SPEC.assert_safe()
    return compute_gencoin(action, packet, ticket)
