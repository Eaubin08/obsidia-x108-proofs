from __future__ import annotations

from typing import Any

from periphery.agent_contracts import AgentLayer, NonSovereignAgentSpec
from periphery.os3_ticket import build_os3_ticket, ticket_is_valid

SPEC = NonSovereignAgentSpec(
    agent_id="OS3_PROOF_TICKET_AGENT",
    layer=AgentLayer.OS3,
    description="Construit un ticket OS3, sans autoriser l'action.",
)

def build(action: Any, packet: Any, envelope: Any):
    SPEC.assert_safe()
    ticket = build_os3_ticket(action, packet, envelope)
    return ticket, ticket_is_valid(ticket)
