# PATCH_TO_REPO_DIFF_PLAN — quoi copier où

## Copier dans `obsidia-x108-proofs`

```text
periphery/__init__.py
periphery/common.py
periphery/constants.py
periphery/validators.py
periphery/merge.py
periphery/hackathon_failures.py
periphery/failure_mapping.py
periphery/data_gate.py
periphery/provenance_gate.py
periphery/memory_governor.py
periphery/eml_compression.py
periphery/energy_thermo.py
periphery/timeverse.py
periphery/ocs_generation.py
periphery/operational_constance.py
periphery/permission_economic.py
periphery/control_plane.py
periphery/sigma_bridge.py
periphery/os3_ticket.py
periphery/gencoin.py
periphery/adapters/*.py
periphery/schemas/*.json

docs/architecture/*.md
docs/hackathons/*.md
docs/periphery/*.md
docs/os3/*.md
docs/gencoin/*.md
docs/freeze/*.md

tests/periphery/*.py
tests/non_sovereignty/*.py
tests/integration/*.py
RUN_*.ps1
```

## Copier dans `Demo-obsidia-x108-proof`

```text
connectors/bank_full_stack_flow.py
connectors/trading_full_stack_flow.py
connectors/gps_full_stack_flow.py
connectors/full_stack_smoke.py
connectors/hackathon_failure_cases.py
connectors/os3_ticket_builder.py
connectors/gencoin_mint_candidate.py
TEST_FULL_STACK_*.ps1
TEST_HACKATHON_FAILURE_CASES.ps1
TEST_GENCOIN_TERRAIN.ps1
TEST_OS3_TERRAIN.ps1
docs/*.md
terrain_reports/*.md
```

## À ne pas toucher

```text
sigma/guard.py
sigma/contracts.py
sigma/protocols.py
sigma/aggregation.py
proofs/
formal/
periphery/brody_memory_readonly/ existant
```

## Après copie

```powershell
cd obsidia-x108-proofs
.\RUN_FULL_STACK_STATIC_CHECK.ps1

cd ..\Demo-obsidia-x108-proof
.\TEST_FULL_STACK_ALL.ps1
```
