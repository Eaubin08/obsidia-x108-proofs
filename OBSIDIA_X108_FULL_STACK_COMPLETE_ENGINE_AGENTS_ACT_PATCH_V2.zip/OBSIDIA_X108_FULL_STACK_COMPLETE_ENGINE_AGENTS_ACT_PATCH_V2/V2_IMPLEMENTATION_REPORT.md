# Rapport d’implémentation V2 — moteur / agents / ACT / feedback

## Pourquoi V2

Le patch V1 avait le bon branchement réel vers les repos, mais il manquait la couche complète définie dans la conversation : moteur, agents, cycle d’action, ACT boundary, orchestration agentique, mémoire feedback candidate et documentation canonique des pépites.

## Ce qui est ajouté

### 1. Agent layer

Fichiers :

```text
periphery/agent_contracts.py
periphery/agent_registry.py
periphery/agents/*.py
```

Chaque agent est non souverain et retourne un `AgentResult` contenant un `PeripheralSignalPacket`. Les agents wrap les gates déjà créés : data, provenance, mémoire, EML, energy, timeverse, OCS, operational constance, permission/economic.

### 2. Action lifecycle

Fichier :

```text
periphery/action_lifecycle.py
```

Formalise les phases de l’action candidate : INPUT_CAPTURED, PERIPHERY_SCORED, SIGMA_ROUTED, X108_EVALUATED, OS3_TICKETED, GENCOIN_EVALUATED, WORLD_ACTION_READY, FEEDBACK_CAPTURED.

### 3. Action sequence governor

Fichier :

```text
periphery/action_sequence_governor.py
```

Couvre les problèmes hackathons : multi-step, async, tool-call risk, plan change, sequence drift. Il transforme une séquence en signaux HOLD/BLOCK_CANDIDATE.

### 4. World action gateway

Fichier :

```text
periphery/world_action_gateway.py
```

Il ne réalise aucune action. Il vérifie seulement si `X108=ALLOW`, OS3 valide, aucun conflit critique, et produit une readiness. Par défaut : `dry_run_only=true`.

### 5. Feedback memory candidate

Fichier :

```text
periphery/feedback_memory_candidate.py
```

Convertit une sortie auditée en candidat mémoire. Aucune écriture mémoire. Policy : CANDIDATE_ONLY / FROZEN_IF_UNSTABLE / READONLY.

### 6. Docs ajoutées

Nouvelles docs :

```text
docs/agents/*
docs/act/*
docs/memory/*
docs/conversation/CONVERSATION_CANON_CAPTURE_V0.md
docs/roadmap/NOT_YET_IMPLEMENTED_AFTER_V2.md
```

Ces docs reprennent les pépites de la conversation : Sigma, Timeverse, Gencoin, OCS, énergie/thermo, provenance, hackathons, agents, ACT, mémoire, Bank/Trading/GPS.

## Ce qui reste encore partiel

- Le gateway ne doit pas exécuter d’action monde réelle sans consentement/runtime séparé.
- Les agents sont des wrappers prêts à brancher ; ils ne remplacent pas les agents Sigma existants.
- L’action sequence governor est un modèle minimal ; il doit être enrichi avec les flows réels du repo.
- Feedback memory candidate ne pousse pas encore vers Graphiti/Brody réel.
- Gencoin reste ledger candidat, pas token, pas mint réel.

## Statut

V2 est un patch de structure complète : il pose les bons fichiers aux bons endroits pour que toute la conversation existe dans le repo `obsidia-x108-proofs`, pas seulement le branchement Sigma.
