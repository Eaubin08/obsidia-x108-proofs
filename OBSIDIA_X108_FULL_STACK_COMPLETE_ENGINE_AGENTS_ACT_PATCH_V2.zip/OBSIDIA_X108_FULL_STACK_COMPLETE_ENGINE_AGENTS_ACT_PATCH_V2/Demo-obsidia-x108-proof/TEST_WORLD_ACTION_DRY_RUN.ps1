python .\connectors\world_action_dry_run_flow.py
