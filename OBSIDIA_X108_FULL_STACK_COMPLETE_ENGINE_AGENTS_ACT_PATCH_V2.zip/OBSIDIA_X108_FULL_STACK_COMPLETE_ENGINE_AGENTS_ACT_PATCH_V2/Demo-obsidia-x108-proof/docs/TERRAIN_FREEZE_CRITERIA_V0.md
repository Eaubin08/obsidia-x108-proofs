# TERRAIN_FREEZE_CRITERIA_V0

Runbook terrain minimal.
