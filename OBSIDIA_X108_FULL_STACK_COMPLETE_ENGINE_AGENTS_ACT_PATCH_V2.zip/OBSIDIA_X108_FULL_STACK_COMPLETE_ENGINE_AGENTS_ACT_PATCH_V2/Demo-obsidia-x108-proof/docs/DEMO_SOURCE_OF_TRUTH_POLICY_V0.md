# DEMO_SOURCE_OF_TRUTH_POLICY_V0

Runbook terrain minimal.
