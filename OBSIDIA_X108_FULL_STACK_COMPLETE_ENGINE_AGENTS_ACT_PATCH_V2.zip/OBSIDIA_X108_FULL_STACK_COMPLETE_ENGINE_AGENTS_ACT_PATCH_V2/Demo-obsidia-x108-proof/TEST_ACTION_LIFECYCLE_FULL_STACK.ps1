python .\connectors\action_lifecycle_full_stack_flow.py
