python .\connectors\feedback_memory_candidate_flow.py
