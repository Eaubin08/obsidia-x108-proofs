python .\connectors\hackathon_failure_cases.py
