from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROOF = ROOT / "obsidia-x108-proofs"
if PROOF.exists():
    sys.path.insert(0, str(PROOF))

import json
from periphery.adapters.bank_adapter import build_bank_action
from periphery.control_plane import run_control_plane
from periphery.sigma_bridge import run_bank_with_periphery
from periphery.os3_ticket import build_os3_ticket
from periphery.feedback_memory_candidate import build_feedback_memory_candidate
action = build_bank_action({"action_id":"feedback-memory-001"})
packet = run_control_plane(action)
envelope = run_bank_with_periphery({}, packet)
ticket = build_os3_ticket(action, packet, envelope)
candidate = build_feedback_memory_candidate(action, ticket, {"outcome":"demo"})
print(json.dumps(candidate.__dict__, indent=2))
print("FEEDBACK_MEMORY_CANDIDATE_PASS")
