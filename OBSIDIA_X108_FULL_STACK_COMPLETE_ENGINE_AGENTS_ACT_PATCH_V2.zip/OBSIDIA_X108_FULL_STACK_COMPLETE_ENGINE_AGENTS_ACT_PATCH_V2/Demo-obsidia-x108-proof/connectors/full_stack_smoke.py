from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = []
if os.environ.get("OBSIDIA_X108_PROOFS_PATH"):
    CANDIDATES.append(Path(os.environ["OBSIDIA_X108_PROOFS_PATH"]))
for parent in HERE.parents:
    CANDIDATES.extend([
        parent / "obsidia-x108-proofs",
        parent / "obsidia-x108-proofs-main",
        parent / "test_merge_x108",
    ])
    CANDIDATES.extend([p for p in parent.glob("*x108*proof*") if p.is_dir()])

for candidate in CANDIDATES:
    if (candidate / "sigma").exists() and (candidate / "periphery").exists():
        sys.path.insert(0, str(candidate))
        break

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(name: str):
    proc = subprocess.run([sys.executable, str(HERE / name)], text=True, capture_output=True)
    print(proc.stdout)
    if proc.returncode != 0:
        print(proc.stderr)
        raise SystemExit(proc.returncode)


def main():
    run("bank_full_stack_flow.py")
    run("trading_full_stack_flow.py")
    run("gps_full_stack_flow.py")
    print("BANK_FULL_STACK_PASS")
    print("TRADING_FULL_STACK_PASS")
    print("GPS_FULL_STACK_PASS")
    print("FULL_STACK_SMOKE_PASS")

if __name__ == "__main__":
    main()
