from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = []
if os.environ.get("OBSIDIA_X108_PROOFS_PATH"):
    CANDIDATES.append(Path(os.environ["OBSIDIA_X108_PROOFS_PATH"]))
for parent in HERE.parents:
    CANDIDATES.extend([
        parent / "obsidia-x108-proofs",
        parent / "obsidia-x108-proofs-main",
        parent / "test_merge_x108",
    ])
    CANDIDATES.extend([p for p in parent.glob("*x108*proof*") if p.is_dir()])

for candidate in CANDIDATES:
    if (candidate / "sigma").exists() and (candidate / "periphery").exists():
        sys.path.insert(0, str(candidate))
        break

from periphery.hackathon_failures import FailureCode


def main():
    print("HACKATHON_FAILURE_CASES_READY")
    for code in FailureCode:
        print(code.value)

if __name__ == "__main__":
    main()
