from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROOF = ROOT / "obsidia-x108-proofs"
if PROOF.exists():
    sys.path.insert(0, str(PROOF))

import json
from periphery.adapters.bank_adapter import build_bank_action
from periphery.control_plane import run_control_plane
from periphery.sigma_bridge import run_bank_with_periphery
from periphery.os3_ticket import build_os3_ticket
from periphery.world_action_gateway import evaluate_world_action_readiness
payload = {"action_id": "world-action-dry-run-001", "gross_value": 1, "total_debt": 0}
action = build_bank_action(payload)
packet = run_control_plane(action)
envelope = run_bank_with_periphery({}, packet)
ticket = build_os3_ticket(action, packet, envelope)
readiness = evaluate_world_action_readiness(action, envelope, ticket)
print(json.dumps(readiness.__dict__, indent=2))
print("WORLD_ACTION_DRY_RUN_PASS")
