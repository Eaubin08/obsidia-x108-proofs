from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = []
if os.environ.get("OBSIDIA_X108_PROOFS_PATH"):
    CANDIDATES.append(Path(os.environ["OBSIDIA_X108_PROOFS_PATH"]))
for parent in HERE.parents:
    CANDIDATES.extend([
        parent / "obsidia-x108-proofs",
        parent / "obsidia-x108-proofs-main",
        parent / "test_merge_x108",
    ])
    CANDIDATES.extend([p for p in parent.glob("*x108*proof*") if p.is_dir()])

for candidate in CANDIDATES:
    if (candidate / "sigma").exists() and (candidate / "periphery").exists():
        sys.path.insert(0, str(candidate))
        break

from periphery.adapters.trading_adapter import build_trading_action, build_trading_state
from periphery.control_plane import run_control_plane
from periphery.sigma_bridge import run_trading_with_periphery
from periphery.os3_ticket import build_os3_ticket
from periphery.gencoin import compute_gencoin


def main():
    payload = {
        "action_id": "trading-demo-001",
        "freshness_score": 0.95,
        "source_count": 3,
        "async_action": True,
        "trajectory_divergence": 0.2,
        "truth_score": 0.8,
        "sigma_score": 0.82,
        "gross_value": 20.0,
        "total_debt": 5.0,
        "drawdown": 0.02,
        "exposure": 0.25,
    }
    action = build_trading_action(payload)
    state = build_trading_state(payload)
    packet = run_control_plane(action)
    envelope = run_trading_with_periphery(state, packet)
    ticket = build_os3_ticket(action, packet, envelope)
    gc = compute_gencoin(action, packet, ticket)
    print(json.dumps({
        "domain": "trading",
        "x108_gate": envelope.x108_gate,
        "reason_code": envelope.reason_code,
        "os3_ticket_id": ticket.ticket_id,
        "gencoin_candidate": gc.gencoin_candidate,
        "mint_allowed": gc.mint_allowed,
    }, indent=2))

if __name__ == "__main__":
    main()
