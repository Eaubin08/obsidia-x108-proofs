from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = []
if os.environ.get("OBSIDIA_X108_PROOFS_PATH"):
    CANDIDATES.append(Path(os.environ["OBSIDIA_X108_PROOFS_PATH"]))
for parent in HERE.parents:
    CANDIDATES.extend([
        parent / "obsidia-x108-proofs",
        parent / "obsidia-x108-proofs-main",
        parent / "test_merge_x108",
    ])
    CANDIDATES.extend([p for p in parent.glob("*x108*proof*") if p.is_dir()])

for candidate in CANDIDATES:
    if (candidate / "sigma").exists() and (candidate / "periphery").exists():
        sys.path.insert(0, str(candidate))
        break

from periphery.adapters.bank_adapter import build_bank_action, build_bank_state
from periphery.control_plane import run_control_plane
from periphery.sigma_bridge import run_bank_with_periphery
from periphery.os3_ticket import build_os3_ticket
from periphery.gencoin import compute_gencoin


def main():
    payload = {
        "action_id": "bank-demo-001",
        "freshness_score": 0.9,
        "source_count": 2,
        "clean_json_ready": True,
        "approval_required": True,
        "approval_obtained": False,
        "gross_value": 10.0,
        "total_debt": 3.0,
        "amount": 42.0,
        "policy_limit": 1000.0,
        "elapsed_s": 108.0,
    }
    action = build_bank_action(payload)
    state = build_bank_state(payload)
    packet = run_control_plane(action)
    envelope = run_bank_with_periphery(state, packet)
    ticket = build_os3_ticket(action, packet, envelope)
    gc = compute_gencoin(action, packet, ticket)
    print(json.dumps({
        "domain": "bank",
        "x108_gate": envelope.x108_gate,
        "reason_code": envelope.reason_code,
        "os3_ticket_id": ticket.ticket_id,
        "gencoin_candidate": gc.gencoin_candidate,
        "mint_allowed": gc.mint_allowed,
    }, indent=2))

if __name__ == "__main__":
    main()
