from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROOF = ROOT / "obsidia-x108-proofs"
if PROOF.exists():
    sys.path.insert(0, str(PROOF))

from periphery.action_lifecycle import ActionLifecycleTrace, ActionPhase
trace = ActionLifecycleTrace("demo-action-lifecycle")
for phase in [ActionPhase.ACTION_CANDIDATE_BUILT, ActionPhase.PERIPHERY_SCORED, ActionPhase.SIGMA_ROUTED, ActionPhase.X108_EVALUATED, ActionPhase.OS3_TICKETED, ActionPhase.GENCOIN_EVALUATED, ActionPhase.WORLD_ACTION_DRY_RUN_READY, ActionPhase.FEEDBACK_CAPTURED, ActionPhase.MEMORY_CANDIDATE_BUILT, ActionPhase.CLOSED]:
    trace.advance(phase, phase.value)
print(json.dumps(trace.to_dict(), indent=2))
print("ACTION_LIFECYCLE_FULL_STACK_PASS")
