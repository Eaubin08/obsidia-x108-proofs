python .\connectors\full_stack_smoke.py
