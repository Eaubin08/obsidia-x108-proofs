python .\connectors\gencoin_mint_candidate.py
