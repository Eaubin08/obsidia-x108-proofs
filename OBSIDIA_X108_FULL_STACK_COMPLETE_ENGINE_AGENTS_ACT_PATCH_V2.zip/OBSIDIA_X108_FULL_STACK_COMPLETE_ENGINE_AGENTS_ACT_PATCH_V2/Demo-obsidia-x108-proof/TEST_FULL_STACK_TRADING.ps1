python .\connectors\trading_full_stack_flow.py
