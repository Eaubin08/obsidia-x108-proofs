# MERGE_RUNBOOK_TERMINAL_FIRST_V2

```powershell
cd obsidia-x108-proofs
.\RUN_FULL_STACK_STATIC_CHECK.ps1
.\RUN_ENGINE_AGENT_ACT_TESTS.ps1

cd ..\Demo-obsidia-x108-proof
.\TEST_FULL_STACK_ALL.ps1
.\TEST_ENGINE_AGENT_ACT_ALL.ps1
```

Vérification dure :

```powershell
git diff -- sigma/guard.py sigma/protocols.py sigma/aggregation.py sigma/contracts.py
```

Aucun changement attendu.
