# MERGE_RUNBOOK_TERMINAL_FIRST — ordre de fusion propre

## 1. Sauvegarde

```powershell
git status --short
git branch backup-before-full-stack-periphery-v1
```

## 2. Copier le patch

Copier uniquement les dossiers/fichiers du patch dans les deux repos.

## 3. Vérifier que le noyau est intact

```powershell
git diff -- sigma/guard.py sigma/contracts.py sigma/protocols.py sigma/aggregation.py
```

Résultat attendu : aucune modification.

## 4. Lancer les tests périphériques

```powershell
.\RUN_PERIPHERY_TESTS.ps1
.\RUN_NON_SOVEREIGNTY_TESTS.ps1
.\RUN_FULL_STACK_STATIC_CHECK.ps1
```

## 5. Lancer le terrain Demo

```powershell
.\TEST_FULL_STACK_BANK.ps1
.\TEST_FULL_STACK_TRADING.ps1
.\TEST_FULL_STACK_GPS.ps1
.\TEST_FULL_STACK_ALL.ps1
```

## 6. Freeze candidat

```powershell
.\RUN_FULL_STACK_FREEZE_CANDIDATE.ps1
```

## 7. Critère de validation

- Aucun changement kernel.
- Tests périphérie PASS.
- Non-souveraineté PASS.
- Demo flows PASS.
- Gencoin = 0 sur HOLD/BLOCK.
- OS3 ticket généré.
