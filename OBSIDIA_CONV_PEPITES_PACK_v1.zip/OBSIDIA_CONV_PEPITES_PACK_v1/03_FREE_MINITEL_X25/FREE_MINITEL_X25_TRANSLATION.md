# Free / Minitel / X.25 / Transpac — Traduction technique pour Obsidia

## Apport réel de l’analogie

Free / Minitel ne servent pas seulement d’inspiration marketing. Ils suggèrent une architecture :

```text
terminal léger -> réseau contrôlé -> service
```

Traduction Obsidia :

```text
agent léger / modèle externe -> réseau Obsidia -> monde réel
```

## Principe 1 — Point de passage unique

Comme le Minitel passait par un réseau structuré, les agents passent par Obsidia.

```text
Agent -> Obsidia Gateway -> World API
```

Pas :

```text
Agent -> Internet libre
```

## Principe 2 — Routage souverain

X.25 / Transpac = circulation contrôlée par routes, sessions, points de service.

Obsidia = routes d’action autorisées.

```text
allowed_route = actor + action + target + scope + ticket
```

## Principe 3 — Terminal léger

Le terminal ne porte pas la souveraineté. Le réseau/protocole la porte.

Traduction :

- LLM interchangeable ;
- agent interchangeable ;
- compute interchangeable ;
- kernel Obsidia invariant.

## Principe 4 — Kiosque

Le Minitel a permis facturation et redistribution par point de passage.

Traduction Gencoin :

- chaque action validée produit une preuve ;
- la preuve peut porter valeur économique ;
- redistribution possible vers humains, opérateurs, pools, infrastructure.

## Principe 5 — Efficience radicale

Free a gagné par design logiciel et réduction de coûts, pas par force brute.

Traduction Obsidia :

- ne pas envoyer tout au gros modèle ;
- classer avant d’appeler ;
- mémoire hiérarchisée ;
- zone réflexe pour cas connus ;
- exploration uniquement quand nécessaire ;
- action toujours gouvernée.

## Pépite

Obsidia peut devenir le Transpac de l’action IA : un réseau souverain de passage contrôlé entre agents et monde réel.
