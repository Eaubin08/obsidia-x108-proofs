# WORLD ACTION BUS

## Concept

Bus d’événements où toutes les intentions d’action sont publiées avant exécution.

```text
Agent -> Intent Event -> World Action Bus -> Obsidia Policy -> Ticket -> Executor
```

## Stack possible

- NATS ;
- Kafka ;
- RabbitMQ ;
- Redis Streams ;
- Postgres queue ;
- Temporal.io pour workflows gouvernés.

## Événement canonique

```json
{
  "event_id": "evt_001",
  "actor": "agent_42",
  "intent_type": "world_call",
  "action": "send_payment",
  "target": "bank_api",
  "payload_hash": "sha256:...",
  "risk_hint": "critical",
  "created_at": "..."
}
```

## Règle

Aucun executor ne consomme directement une intention agent.
Il consomme uniquement un ticket Obsidia validé.
