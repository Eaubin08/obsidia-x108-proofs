# PACK COM — Obsidia comme filtre souverain des appels monde

## Tagline principale

Obsidia — le filtre souverain entre l’IA et le monde.

## Phrases courtes

- Une IA peut penser. Obsidia décide si elle agit.
- On ne sécurise pas une IA en lui faisant confiance. On sécurise son passage à l’acte.
- Le calcul peut venir de n’importe où. Le droit d’agir reste local.
- Pas de ticket souverain, pas d’action monde.
- Obsidia n’est pas une IA. Obsidia est la frontière entre l’IA et le réel.

## Pitch 30 sec

Aujourd’hui, les IA sont directement connectées au monde : API, paiements, systèmes, robots.
Le problème n’est pas seulement ce qu’elles pensent. Le problème, c’est qu’on les laisse agir.
Obsidia coupe ce lien direct.
Une IA peut proposer, simuler, calculer. Mais elle ne peut pas toucher le monde sans validation souveraine.
Obsidia devient le filtre obligatoire entre intelligence artificielle et action réelle.

## Pitch investisseur

L’IA devient une infrastructure d’exécution mondiale, mais il manque une couche critique : le contrôle souverain du passage à l’action.
Obsidia se place entre les agents IA et le monde réel. Chaque appel monde devient une demande gouvernée, traçable et refusable.
Ce n’est pas un modèle IA. C’est une couche d’infrastructure : le firewall actionnel de l’économie agentique.

## Version institutionnelle

La question n’est plus seulement : que produit une IA ?
La question devient : qui contrôle son passage à l’action ?
Obsidia introduit une couche souveraine de validation entre systèmes IA et infrastructures réelles.
La puissance peut rester globale. Le contrôle doit redevenir local.
