# Obsidia & L’Art de la guerre — Positionnement

## Formule canonique

Nous n’avons pas cherché à copier les textes militaires.
Nous avons cherché la sécurité algorithmique parfaite.
Mais en poussant la logique jusqu’au bout, nous nous sommes rendu compte que l’architecture d’Obsidia, à tous les étages, recoupe mathématiquement les principes de L’Art de la guerre.

## Principe

L’Art de la guerre ne célèbre pas la violence. Il cherche la victoire avant le combat.

Obsidia ne combat pas l’IA.
Obsidia contrôle le terrain où l’IA peut agir.

## Correspondances

| Principe stratégique | Traduction Obsidia |
|---|---|
| Gagner avant le combat | non-bypass ex ante |
| Contrôler le terrain | filtrage des appels monde |
| Couper les lignes adverses | pas d’accès direct API / réseau |
| Soumettre sans combattre | IA subordonnée au kernel |
| Éviter l’affrontement inutile | HOLD/BLOCK avant irréversible |
| Maîtriser l’information | mémoire gouvernée / audit |
| Ne pas dépendre de la force brute | efficience / kernel / routage |

## Punchline

Obsidia transforme les principes de survie stratégique en architecture de sécurité algorithmique.
