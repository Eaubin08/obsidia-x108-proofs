# Backlog branchable Obsidia

## Priorité 1 — World Call Filtering MVP

- Créer `world_call_classifier.py`
- Créer `sovereign_ticket.py`
- Créer `obsidia_gateway.py`
- Créer test `no_ticket_no_action`
- Créer test `irreversible_hold_before_tau`

## Priorité 2 — Free/Minitel infra translation

- Ajouter World Action Bus minimal
- Ajouter routes autorisées type X.25
- Ajouter egress deny-by-default
- Ajouter allowlist endpoints

## Priorité 3 — Gencoin off-chain

- Créer CognitiveValueEvent
- Créer score CV v0
- Créer distribution policy v0
- Interdire mint si invariant violé

## Priorité 4 — Marketing / public

- Page “Filtrage des appels monde”
- Slide “IA -> Obsidia -> Monde”
- Pitch investisseurs
- Schéma Art de la guerre algorithmique

## Priorité 5 — Formalisation

- Théorème NoWorldCallWithoutTicket
- Théorème IrreversibleHoldBeforeTau
- Théorème GatewayEnforcesTicket
- Théorème GencoinMintRequiresValidatedValue
