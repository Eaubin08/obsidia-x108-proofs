# GENCOIN — Couche valeur cognitive humain-IA

## Positionnement

Gencoin n’est pas d’abord une crypto spéculative.

C’est une couche économique indexée sur :

```text
valeur cognitive validée + preuve d’action réelle + redistribution gouvernée
```

## Problème

Monde IA brut :

```text
IA produit -> plateformes capturent -> humains perdent
```

Monde Obsidia / Gencoin :

```text
Humain + IA produisent -> Obsidia valide -> Gencoin redistribue
```

## Valeur cognitive

La valeur cognitive peut venir de :

- intuition humaine ;
- architecture ;
- réduction de risque ;
- résolution de conflit ;
- création de structure ;
- décision prudente ;
- arbitrage ;
- preuve ;
- amélioration d’un système ;
- contribution IA utile sous gouvernance.

## Principe

```text
travail ancien = temps
travail IA brut = compute
travail Obsidia/Gencoin = valeur cognitive validée
```

## Formule conceptuelle

```text
CognitiveValue = f(Novelty, Utility, Coherence, RiskReduction, Reusability, ProofQuality, HumanSignal, AISignal)
```

## Rôle Obsidia

Obsidia ne “mint” pas sur hype.
Obsidia valide :

- cohérence ;
- utilité ;
- preuve ;
- réduction de risque ;
- action réelle ;
- absence de violation.

## Rôle blockchain / crypto

La blockchain n’est pas le produit.
Elle est :

- registre ;
- preuve ;
- redistribution ;
- audit ;
- propriété fractionnée ;
- règlement économique.

## Pépite

Obsidia = système nerveux souverain.
Gencoin = système circulatoire économique.
