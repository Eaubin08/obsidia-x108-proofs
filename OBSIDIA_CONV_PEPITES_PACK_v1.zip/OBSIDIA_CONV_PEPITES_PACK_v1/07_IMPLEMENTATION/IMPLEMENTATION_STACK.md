# Stack d’implémentation cible

## Minimal local MVP

- Python 3.11+
- FastAPI
- Pydantic
- SQLite / JSONL
- Docker network isolation
- pytest
- SHA256 manifest

## Gateway

- FastAPI custom gateway en V1
- Envoy / Kong / Traefik en V2
- deny-by-default network egress

## Bus

- Redis Streams ou NATS en V1
- Kafka si volume élevé
- Temporal.io pour workflows longs

## Policy

- règles JSON/YAML versionnées
- moteur Python déterministe
- priorité BLOCK > HOLD > ACT

## X-108

- temporal gate pour irréversible
- seuil de cohérence
- logs replayables

## Mémoire

- Graphiti / Neo4j pour contexte
- frozen adapter read-only
- context packets
- snapshots JSON

## Audit

- JSONL logs
- hash chain
- Merkle root
- manifest SHA256
- timestamping RFC3161 optionnel

## Crypto / Gencoin

- off-chain validation d’abord
- on-chain settlement ensuite
- L2 ou chain privée possible
- smart contract seulement après schéma de valeur stabilisé
