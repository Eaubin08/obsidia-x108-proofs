# Cibles de formalisation Lean / TLA+

## Théorème 1 — No World Call Without Ticket

Énoncé : aucune action monde ne peut être exécutée sans ticket valide.

```text
theorem no_world_call_without_ticket:
  execute a = true -> exists t, valid_ticket t a = true
```

## Théorème 2 — Irreversible Holds Before Tau

```text
irreversible a -> elapsed a < tau -> decision a = HOLD
```

## Théorème 3 — Invariant Violation Blocks

```text
violates_invariant a -> decision a = BLOCK
```

## Théorème 4 — Agent Has No Direct World Capability

```text
agent_capability agent world_call = false
```

## Théorème 5 — Gateway Enforces Ticket

```text
gateway_execute request = true -> valid_ticket request.ticket request.action = true
```

## Théorème 6 — Gencoin Mint Requires Validated Value

```text
mint event > 0 -> validated_by_obsidia event = true
```

## Théorème 7 — Invariant Violation Prevents Mint

```text
violates_invariant event -> mint event = 0
```
