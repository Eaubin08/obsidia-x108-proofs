# Formules conceptuelles branchables

## 1. Non-bypass

```text
∀ a ∈ ActionsMonde,
Execute(a) => ExistsValidTicket(a)
```

Contraposée opérationnelle :

```text
¬ExistsValidTicket(a) => ¬Execute(a)
```

## 2. Décision par invariants

```text
Violation(Invariant, action) => Decision(action) ∈ {HOLD, BLOCK}
```

## 3. Gate temporelle X-108

```text
Irreversible(action) ∧ elapsed_time < τ => HOLD
```

```text
Irreversible(action) ∧ coherence < θ => HOLD
```

```text
InvariantViolation(action) => BLOCK
```

## 4. Classement appel monde

```text
WorldCallClass(action) ∈ {NO, READ_ONLY, REVERSIBLE, IRREVERSIBLE, CRITICAL, FORBIDDEN}
```

## 5. Priorité stricte

```text
BLOCK > HOLD > ACT
```

## 6. Valeur cognitive Gencoin

Formule conceptuelle :

```text
CV = αN + βU + γC + δR + εP + ζH + ηA
```

où :

- N = Novelty
- U = Utility
- C = Coherence
- R = RiskReduction
- P = ProofQuality
- H = HumanSignal
- A = AISignal

Sous contrainte :

```text
InvariantViolation => CV_mint = 0
```

## 7. Redistribution

```text
Reward = Mint(CV_validated) * DistributionPolicy
```

## 8. Souveraineté locale

```text
ComputeProvider ≠ DecisionAuthority
```

Le calcul peut venir d’ailleurs. L’autorité d’action reste locale.
