# OBSIDIA_CONV_PEPITES_PACK_v1

Pack de stabilisation issu de la conversation : sources externes, pépites marketing, stack technique, formules, et blocs branchables à Obsidia.

Objectif : transformer la discussion en artefacts exploitables, sans prétendre que ces éléments sont déjà tous implémentés dans le kernel.

Statut : PACK_CONCEPT_TECHNIQUE_BRANCHABLE
Décision kernel : NONE
Mutation X-108 : NONE
Autorité décisionnelle : KX108_ONLY

## Contenu

- `01_CORE/` : statut, doctrine, synthèse des pépites.
- `02_WORLD_CALL_FILTERING/` : filtrage des appels monde, ticket souverain, gateway.
- `03_FREE_MINITEL_X25/` : traduction technique Free / Minitel / X.25 / Transpac.
- `04_GENCOIN/` : valeur cognitive humain-IA, crypto, redistribution, preuve de valeur.
- `05_MARKETING/` : tagline, pitch, investisseurs, institutionnel, Art de la guerre.
- `06_MATH_FORMALIZATION/` : formules, invariants, pseudo-spécifications.
- `07_IMPLEMENTATION/` : stack cible, modules, API, schémas JSON.
- `08_TESTS/` : plan de tests, smoke tests, propriétés à prouver.
- `09_BACKLOG/` : chantiers à brancher dans Obsidia.
