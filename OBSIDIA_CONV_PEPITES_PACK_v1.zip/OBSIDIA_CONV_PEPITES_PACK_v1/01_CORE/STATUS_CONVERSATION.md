# STATUS — Ce que la conversation a validé, déplacé, laissé ouvert

## VALIDÉ

La conversation a validé un angle public et technique central :

> Obsidia est le filtre souverain entre l’IA et le monde réel.

Forme canonique :

```text
[ LLM / Agent / Robot / App ] -> [ OBSIDIA ] -> [ API / Internet / DB / Paiement / Robot / Monde réel ]
```

Le cœur n’est pas “rendre l’IA gentille”, mais contrôler son passage à l’action.

## DÉPLACÉ

Obsidia passe de :

```text
kernel profond / OS cognitif / gouvernance IA
```

à :

```text
point de passage obligatoire entre intelligence et action
```

Ce déplacement rend le projet plus lisible publiquement et techniquement branchable.

## LAISSÉ OUVERT

Ce qui reste à fermer n’est pas la vision :

- nom officiel du protocole public ;
- schéma standard d’intégration ;
- benchmark public de non-bypass ;
- implémentation gateway / bus / egress control ;
- packaging investisseurs / institutionnel ;
- branchement Gencoin comme couche économique.
