# Index des pépites

## P1 — Filtrage des appels monde
Aucune action vers le réel sans validation souveraine.

## P2 — Ticket souverain
Pas de ticket, pas d’action. Le ticket devient le passeport d’exécution.

## P3 — L’IA n’a pas les mains
L’agent peut vouloir agir, mais ne possède pas les accès au monde.

## P4 — Obsidia contrôle le terrain
Obsidia ne combat pas l’IA. Obsidia contrôle le terrain où l’IA peut agir.

## P5 — Art de la guerre algorithmique
On n’a pas copié Sun Tzu : on a cherché la sécurité parfaite, et la forme finale recoupe les principes de survie stratégique.

## P6 — Free / Minitel / X.25
Ne pas battre les géants par la force brute. Les battre par protocole, routage, efficience, point de passage.

## P7 — Transpac de l’action IA
Obsidia peut devenir le réseau souverain de passage contrôlé entre agents et monde réel.

## P8 — Gencoin
Mesurer et redistribuer la valeur cognitive et productive validée par Obsidia.

## P9 — Valeur cognitive humain-IA
La vraie richesse post-IA n’est pas le compute seul, mais la cognition utile validée : intuition humaine + amplification IA + gouvernance Obsidia.
