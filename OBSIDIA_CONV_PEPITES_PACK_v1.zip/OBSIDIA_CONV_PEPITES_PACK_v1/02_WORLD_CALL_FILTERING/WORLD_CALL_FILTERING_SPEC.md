# SPEC — Filtrage des appels monde

## Définition

Filtrage des appels monde = toute tentative d’action externe doit passer par Obsidia avant d’atteindre le réel.

Un appel monde inclut :

- API externe ;
- paiement ;
- écriture DB production ;
- envoi email/message ;
- déploiement code ;
- shell/system command ;
- robot/actuateur ;
- accès réseau ;
- copie de données ;
- mutation mémoire permanente.

## Principe absolu

```text
No Sovereign Ticket -> No World Call
```

## Flux

```text
1. Agent propose une action
2. Obsidia intercepte
3. Normalisation en intent canonique
4. Classification world-call
5. Vérification policy / invariants
6. Gate X-108 si action irréversible
7. HOLD / BLOCK / ACT_CANDIDATE
8. Ticket souverain si validé
9. Execution Gateway appelle le monde
10. Logs + hash + replay
```

## Classes d’appel monde

```text
NO_WORLD_CALL
READ_ONLY_WORLD_CALL
REVERSIBLE_WORLD_CALL
IRREVERSIBLE_WORLD_CALL
CRITICAL_WORLD_CALL
FORBIDDEN_WORLD_CALL
```

## Décisions possibles

```text
HOLD    : attente / délai / incohérence / manque de preuve
BLOCK   : violation invariant / interdit / risque critique
ACT     : action autorisée via ticket souverain
ESCALATE: décision humaine requise
```
