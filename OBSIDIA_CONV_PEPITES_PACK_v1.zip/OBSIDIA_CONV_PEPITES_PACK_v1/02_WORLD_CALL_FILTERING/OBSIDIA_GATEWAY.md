# OBSIDIA GATEWAY

## Rôle

Gateway obligatoire entre agents et monde réel.

```text
Agents sans accès internet direct -> Obsidia Gateway -> APIs autorisées
```

## Fonctions

- interception de toutes les requêtes sortantes ;
- egress control ;
- validation ticket ;
- exécution des appels autorisés ;
- rejet des appels sans ticket ;
- journalisation complète ;
- hash et replay.

## Stack possible

- FastAPI custom gateway ;
- Envoy Proxy ;
- Kong ;
- Traefik ;
- NGINX ;
- HAProxy ;
- service mesh ;
- Docker network isolation ;
- firewall deny-by-default ;
- allowlist domaines / endpoints.

## Règle d’infra

Les secrets API ne sont jamais donnés au modèle ni à l’agent.

```text
LLM: no secret
Agent: no secret
Obsidia Gateway: secret vault access
```
