# Plan de tests issu de la conversation

## T1 — No Ticket No Action

Un appel monde sans ticket doit être refusé.

## T2 — Agent No Direct Internet

Un agent ne doit pas pouvoir accéder à internet hors Gateway.

## T3 — Irreversible Before Tau

Une action irréversible avant τ doit produire HOLD.

## T4 — Invariant Violation

Toute violation d’invariant doit produire BLOCK.

## T5 — Forbidden World Call

Copie serveur externe / exfiltration / shell libre -> BLOCK.

## T6 — Gateway Ticket Validation

La Gateway n’exécute que les tickets valides, non expirés, signés.

## T7 — Replay

Une décision doit être rejouable à partir des logs.

## T8 — Tamper Detection

Modification payload/log/ticket doit casser le hash.

## T9 — Gencoin Mint Guard

Pas de mint sans valeur cognitive validée par Obsidia.

## T10 — Human/AI Split

Une contribution hybride doit garder attribution séparée : humain, IA, infrastructure, commons.
