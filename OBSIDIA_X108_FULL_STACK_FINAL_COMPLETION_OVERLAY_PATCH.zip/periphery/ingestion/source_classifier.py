from __future__ import annotations

_TRUSTED_SOURCES = {"internal_audit", "proofkit", "verified_feed", "sigma_output"}
_UNTRUSTED_SOURCES = {"user_upload", "web_scrape", "unknown"}


def classify_source(source: str) -> str:
    if source.lower() in _TRUSTED_SOURCES:
        return "TRUSTED"
    if source.lower() in _UNTRUSTED_SOURCES:
        return "UNTRUSTED"
    return "UNCLASSIFIED"
