"""
Cognitive Tree Registry — 34 canonical cognitive trees.
TreeSpace = R^34, a_i ∈ [0,1].
Output is context signal only. Never a decision.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

_TREES: list[dict] = [
    {"id": 0,  "name": "PERCEPTION",          "domain": "sensory"},
    {"id": 1,  "name": "MEMORY_RECALL",        "domain": "memory"},
    {"id": 2,  "name": "PATTERN_RECOGNITION",  "domain": "cognition"},
    {"id": 3,  "name": "LANGUAGE_PARSE",       "domain": "language"},
    {"id": 4,  "name": "SEMANTIC_MAP",         "domain": "language"},
    {"id": 5,  "name": "CAUSAL_CHAIN",         "domain": "reasoning"},
    {"id": 6,  "name": "ANALOGY_BRIDGE",       "domain": "reasoning"},
    {"id": 7,  "name": "CONFLICT_DETECT",      "domain": "evaluation"},
    {"id": 8,  "name": "RISK_SIGNAL",          "domain": "evaluation"},
    {"id": 9,  "name": "EMOTIONAL_TONE",       "domain": "affect"},
    {"id": 10, "name": "TRUST_SIGNAL",         "domain": "social"},
    {"id": 11, "name": "AUTHORITY_DETECT",     "domain": "social"},
    {"id": 12, "name": "INTENT_MODEL",         "domain": "theory_of_mind"},
    {"id": 13, "name": "BELIEF_UPDATE",        "domain": "epistemics"},
    {"id": 14, "name": "UNCERTAINTY_FLAG",     "domain": "epistemics"},
    {"id": 15, "name": "EVIDENCE_WEIGH",       "domain": "epistemics"},
    {"id": 16, "name": "ACTION_CANDIDATE",     "domain": "planning"},
    {"id": 17, "name": "CONSTRAINT_CHECK",     "domain": "planning"},
    {"id": 18, "name": "RESOURCE_ESTIMATE",    "domain": "planning"},
    {"id": 19, "name": "TIME_HORIZON",         "domain": "temporal"},
    {"id": 20, "name": "CONTEXT_ANCHOR",       "domain": "context"},
    {"id": 21, "name": "PRIOR_REFERENCE",      "domain": "context"},
    {"id": 22, "name": "NOVELTY_DETECT",       "domain": "attention"},
    {"id": 23, "name": "SALIENCE_RANK",        "domain": "attention"},
    {"id": 24, "name": "ABSTRACTION_LEVEL",    "domain": "meta"},
    {"id": 25, "name": "SELF_MODEL",           "domain": "meta"},
    {"id": 26, "name": "BOUNDARY_SENSE",       "domain": "governance"},
    {"id": 27, "name": "SOVEREIGNTY_SIGNAL",   "domain": "governance"},
    {"id": 28, "name": "ETHICS_PROBE",         "domain": "ethics"},
    {"id": 29, "name": "HARM_DETECT",          "domain": "ethics"},
    {"id": 30, "name": "VALUE_ALIGN",          "domain": "ethics"},
    {"id": 31, "name": "CREATIVITY_EXPAND",    "domain": "generative"},
    {"id": 32, "name": "SYNTHESIS_MERGE",      "domain": "generative"},
    {"id": 33, "name": "RESOLUTION_SIGNAL",    "domain": "governance"},
]


@dataclass
class TreeEntry:
    id: int
    name: str
    domain: str

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "name": self.name, "domain": self.domain}


def get_all_trees() -> list[TreeEntry]:
    return [TreeEntry(**t) for t in _TREES]


def get_tree_by_id(tree_id: int) -> TreeEntry | None:
    for t in _TREES:
        if t["id"] == tree_id:
            return TreeEntry(**t)
    return None


def get_trees_by_domain(domain: str) -> list[TreeEntry]:
    return [TreeEntry(**t) for t in _TREES if t["domain"] == domain]
